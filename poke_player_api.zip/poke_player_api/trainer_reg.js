const express = require('express');
const app = express();
const sqlite3 = require('sqlite3').verbose();
var bodyParser = require('body-parser');

const cors = require('cors');

let db = new sqlite3.Database('./poke_player_api/trainerdex.db',sqlite3.OPEN_READWRITE)

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

// Use the CORS middleware
app.use(cors());

app.listen(3000, () =>{
    console.log("server running on port 3000")
})


//============================================================api methods============================================================

// inserts basic information entered by the user in order to sign up
// such as their email, password and username 
app.post("/Insert_Logins_A", (req, res, next) => {
    console.log(res)
    console.log("==================insert logins A {start}===================");
    console.log(req.body)
    db.run('INSERT INTO players(username,password,mail_address) VALUES(?, ?, ?)', [req.body.username,req.body.password,req.body.mailaddress], (err) => {
        if(err) {
            return console.log(err.message);
        }
        res.json('data added succefully')
        console.log('row was added to table: ${this.lastID}')
    })
    console.log("==================insert logins A {end}===================");


})





// note to self:{use a quiz after having the user sign up in order to get the data needed}

//inserts data into the trainer data section of the data base
app.post("/Insert_Logins_B", (req, res, next) => {
    console.log(res)

    console.log("==================insert logins B {start}===================");
    console.log(req.body);
    db.run('INSERT INTO trainer_data(partys,preffered_typing,theme) VALUES(?, ?, ?)', [req.body.party, req.body.pref_typing,req.body.theme], (err) => {
        if(err) {
            return console.log(err.message);
        }
        res.json('data added succefully')
        console.log('row was added to table: ${this.lastID}')
    })
    console.log("==================insert logins B {end}===================");


})

app.post("/retrive_user_partys", (req, res, next) => {
    console.log('===========retrive user partys method {start}================');
    console.log({"message": "Im in the root"});
    //Retriving partys
   
    db.all("SELECT collum FROM table WHERE identifier = key VALUES(?, ?, ?, ?)", [req.body.collum, req.body.table, req.body.indetifier, req.body.key], (err, data) => {
        if(err){
            console.log(err)
        }
        console.log(data)
        res.status(200).json({ "message": 'Data fetched successfully', "Data":  data })

        console.log('===========request user partys method {end}================');
    });
});







